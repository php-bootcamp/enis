<?php

trait SQLCrud{

public function create(SQLQuery $query){

}
public function update(SQLQuery $query){

}
public function delete(SQLQuery $query){

}
public function get(SQLQuery $query){

}
public function first(SQLQuery $query){

}
}
