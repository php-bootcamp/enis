<?php



interface IQuery{
    public function compile();
}


