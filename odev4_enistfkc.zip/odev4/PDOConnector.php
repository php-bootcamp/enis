<?php

 

trait PDOConnector{
    public function connect() {

    }
    public function disconnect() {

    }
    protected function setParams(array $params) {}

    
}


